AOMS Protocol v1.1 Bundle
-------------------------
Included:
- AOMS_Protocol_v1.1.md      (Markdown release)
- AOMS_Protocol_v1.1.sha256  (SHA-256 hash of the Markdown content)
- plausibility_ledger.csv     (starter CSV ledger)

Suggested use on WordPress:
- Upload this ZIP to your Media Library if ZIPs are allowed; link it in your post.
- If ZIPs are not allowed, host the ZIP externally (GitHub, Google Drive, Dropbox) and link it.
- Alternatively, rename file extensions to .txt to upload individually.